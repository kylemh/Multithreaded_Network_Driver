package org.hwdb.srpc;

import org.junit.Before;
import org.junit.Test;
import org.omg.IOP.ComponentIdHelper;

import static org.junit.Assert.*;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class EndpointTest {
    InetAddress addr;
    Endpoint ep;
    Endpoint ep2;
    Endpoint ep3;
    
    @Before
    public void setUp() throws UnknownHostException {
        byte[] localhost = {127,0,0,1};
        addr = InetAddress.getByAddress(localhost);
        ep = new Endpoint(addr, 20000, 12344);
        ep2 = new Endpoint(addr, 20000, 12344);
        ep3 = new Endpoint(addr, 200, 1232);
    }

    @Test
    public void testHashCode(){
        assertTrue((addr.hashCode() ^ 20000 ^ 12344) ==  ep.hashCode());
    }


    @Test
    public void testEquality() {
        assertTrue(ep.equals(ep2));
    }

    @Test
    public void testNotEqual() {
        assertFalse(ep.equals(ep3));
    }

    @Test
    public void testHashCodesShouldBeEqualIfObjectEqual(){
        assertTrue(ep.hashCode() == ep2.hashCode());
    }

    @Test
    public void hashCodesShouldBeDifferentIfObjectsNotEqual() {
        assertFalse(ep.hashCode() == ep3.hashCode());
    }

}
