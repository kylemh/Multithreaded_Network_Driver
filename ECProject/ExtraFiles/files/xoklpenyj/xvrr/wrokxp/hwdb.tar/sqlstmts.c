/* sqlstmts.c
 * 
 * SQL statement definitions (used by parser)
 * 
 * Created by Oliver Sharma on 2009-05-03.
 * Copyright (c) 2009. All rights reserved.
 */
#include "sqlstmts.h"
#include "util.h"

#include <string.h>

const int sql_colattrib_types[6] = {0,1,2,3,4,5};
const char *colattrib_name[6] = {"none", "count", "min", "max", "avg", "sum"};

sqlwindow *sqlstmt_new_stubwindow() {
	sqlwindow *win;
	
	win = mem_alloc(sizeof(sqlwindow));
	win->type = SQL_WINTYPE_NONE;
	win->num = -1;
	win->unit = -1;
	
	return win;
}


sqlwindow *sqlstmt_new_timewindow(int num, int unit) {
	sqlwindow *win;
	
	win = mem_alloc(sizeof(win));
	win->type = SQL_WINTYPE_TIME;
	win->num = num;
	win->unit = unit;
	
	return win;
}


sqlwindow *sqlstmt_new_timewindow_now() {
	sqlwindow *win;
	
	win = mem_alloc(sizeof(win));
	win->type = SQL_WINTYPE_TIME;
	win->num = -1;
	win->unit = SQL_WINTYPE_TIME_NOW;
	
	return win;
}


sqlwindow *sqlstmt_new_tuplewindow(int num) {
	sqlwindow *win;
	
	win = mem_alloc(sizeof(win));
	win->type = SQL_WINTYPE_TPL;
	win->num = num;
	win->unit = -1;
	
	return win;
}

sqlfilter *sqlstmt_new_filter_equal(char *name, int value) {
	sqlfilter *filter;
	
	filter = mem_alloc(sizeof(filter));
	filter->varname = name;
	filter->value = value;
	filter->sign = SQL_FILTER_EQUAL;
	
	return filter;
}

sqlfilter *sqlstmt_new_filter_greater(char *name, int value) {
	sqlfilter *filter;
	
	filter = mem_alloc(sizeof(filter));
	filter->varname = name;
	filter->value = value;
	filter->sign = SQL_FILTER_GREATER;
	
	return filter;
}


sqlfilter *sqlstmt_new_filter_less(char *name, int value) {
	sqlfilter *filter;
	
	filter = mem_alloc(sizeof(filter));
	filter->varname = name;
	filter->value = value;
	filter->sign = SQL_FILTER_LESS;
	
	return filter;
}

sqlfilter *sqlstmt_new_filter_greatereq(char *name, int value) {
	sqlfilter *filter;
	
	filter = mem_alloc(sizeof(filter));
	filter->varname = name;
	filter->value = value;
	filter->sign = SQL_FILTER_GREATEREQ;
	
	return filter;
}


sqlfilter *sqlstmt_new_filter_lesseq(char *name, int value) {
	sqlfilter *filter;
	
	filter = mem_alloc(sizeof(filter));
	filter->varname = name;
	filter->value = value;
	filter->sign = SQL_FILTER_LESSEQ;
	
	return filter;
}

int sqlstmt_calc_len(sqlinsert *insert) {
	int total;
	int i;
	
	total = strlen(insert->tablename) + 1;
	total += insert->ncols * sizeof(char*);
	for (i=0; i < insert->ncols; i++) {
		total += strlen(insert->colval[i]) + 1;
	}
	
	debugvf("Calculated insert length to be %d\n", total);
	return total;
	
}
