/*
 * flow monitor client for the Homework Database
 *
 * usage: ./flowmonitor [-h host] [-p port]
 *
 * periodically solicits all Flows records received by the database in the
 * period; converts the returned results to a binary array that can then
 * be processed and displayed to the user
 *
 * this is a primitive version of the monitor; for it to be used successfully,
 * it will be necessary for the program to map from protocol numbers to 
 * protocol names, binary IP addresses to host names, and well-known port
 * numbers to the applications with which they are associated.
 */

#include "config.h"
#include "util.h"
#include "rtab.h"
#include "srpc.h"
#include "flowmonitor.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <arpa/inet.h>

#define USAGE "./flowmonitor [-h host] [-p port]"
#define TIME_DELTA 5		/* in seconds */

static struct timespec time_delay = {TIME_DELTA, 0};

static void processresults(char *buf, unsigned int len);

int main(int argc, char *argv[]) {
	RpcSocket rps;
	RpcConnection rpc;
	char query[SOCK_RECV_BUF_LEN];
	char resp[SOCK_RECV_BUF_LEN];
	int qlen;
	unsigned len;
	char *host;
	unsigned short port;
	int i, j;
	struct timeval expected, current;

	host = HWDB_SERVER_ADDR;
	port = HWDB_SERVER_PORT;
	for (i = 1; i < argc; ) {
		if ((j = i + 1) == argc) {
			fprintf(stderr, "usage: %s\n", USAGE);
			exit(1);
		}
		if (strcmp(argv[i], "-h") == 0)
			host = argv[j];
		else if (strcmp(argv[i], "-p") == 0)
			port = atoi(argv[j]);
		else {
			fprintf(stderr, "Unknown flag: %s %s\n", argv[i], argv[j]);
		}
		i = j + 1;
	}
	if (!rpc_init(0)) {
		fprintf(stderr, "Failure to initialize rpc system\n");
		exit(-1);
	}
	rps = rpc_socket(host, port);
	if (!(rpc = rpc_connect(rps, "HWDB", 1l))) {
		fprintf(stderr, "Failure to connect to HWDB at %s:%05u\n",
				host, port);
		exit(-1);
	}
	sprintf(query, "SQL:select * from Flows [ range %d seconds]\n",
			    TIME_DELTA);
	qlen = strlen(query) + 1;
	gettimeofday(&expected, NULL);
	expected.tv_usec = 0;
	for (;;) {
	    expected.tv_sec += TIME_DELTA;
            gettimeofday(&current, NULL);
	    if (current.tv_usec > 0) {
	        time_delay.tv_nsec = 1000 * (1000000 - current.tv_usec);
	        time_delay.tv_sec = expected.tv_sec - current.tv_sec - 1;
	    } else {
		time_delay.tv_nsec = 0;
		time_delay.tv_sec = expected.tv_sec - current.tv_sec;
	    }
            nanosleep(&time_delay, NULL);
	    if (! rpc_call(rpc, query, qlen, resp, sizeof(resp), &len)) {
		fprintf(stderr, "rpc_call() failed\n");
		break;
	    }
	    resp[len] = '\0';
	    processresults(resp, len);
	}
	rpc_disconnect(rpc);
	exit(0);
}

/*
 * converts the returned Flows tuples into a dynamically-allocated array
 * of FlowData structures.  after the user is finished with the array,
 * mon_free should be called to return the storage to the heap
 *
 * Assumes that the Flow tuple is as defined by hwdb.rc - i.e.
 *
 * create table Flows (proto integer, saddr varchar(16), sport integer,
 * daddr varchar(16), dport integer, npkts integer, nbytes integer)
 */
BinResults *mon_convert(Rtab *results) {
    BinResults *ans;
    unsigned int i;

    if (! results || results->mtype != 0)
        return NULL;
    if (!(ans = (BinResults *)malloc(sizeof(BinResults))))
        return NULL;
    ans->nflows = results->nrows;
    ans->data = (FlowData **)calloc(ans->nflows, sizeof(FlowData *));
    if (! ans->data) {
        free(ans);
	return NULL;
    }
    for (i = 0; i < ans->nflows; i++) {
        char **columns;
        FlowData *p = (FlowData *)malloc(sizeof(FlowData));
	if (!p) {
            mon_free(ans);
	    return NULL;
	}
	ans->data[i] = p;
	columns = rtab_getrow(results, i);
	p->proto = atoi(columns[0]) & 0xff;
	inet_aton(columns[1], &p->ip_src);
	p->sport = atoi(columns[2]) & 0xffff;
	inet_aton(columns[3], &p->ip_dst);
	p->dport = atoi(columns[4]) & 0xffff;
	p->packets = atol(columns[5]);
	p->bytes = atol(columns[6]);
    }
    return ans;
}

void mon_free(BinResults *p) {
    unsigned int i;

    if (p) {
        for (i = 0; i < p->nflows && p->data[i]; i++)
            free(p->data[i]);
        free(p);
    }
}

static void processresults(char *buf, unsigned int len) {
    Rtab *results;
    char stsmsg[RTAB_MSG_MAX_LENGTH];
    BinResults *p;

    results = rtab_unpack(buf, len);
    if (results && ! rtab_status(buf, stsmsg)) {
        p = mon_convert(results);
	/* do something with the data pointed to by p */
	printf("Retrieved %ld flow records from database\n", p->nflows);
	mon_free(p);
    }
    rtab_free(results);
}
