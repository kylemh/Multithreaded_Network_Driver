/**
 * Tuple
 * 
 * Created by Oliver Sharma on 2009-04-16
 * Copyright (c) 2009. All rights reserved.
 */
#include "tuple.h"
#include "mem.h"
#include <stdio.h>
#include <sys/time.h>

char *tpl_timestamp_to_string(struct timeval *tstamp) {
	char b[64], *s;
	sprintf(b, "%ld.%06ld", tstamp->tv_sec,
		tstamp->tv_usec & 0xfffff);  /* mask out dropped bit */
	s = str_dupl(b);
	return s;
}
