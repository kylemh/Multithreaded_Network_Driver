/*
 * tuple.h - define data structure for tuples
 */
#ifndef _TUPLE_H_
#define _TUPLE_H_

#include <sys/time.h>

#define MAX_TUPLE_SIZE 4096

union Tuple {
    unsigned char bytes[MAX_TUPLE_SIZE];
    char *ptrs[MAX_TUPLE_SIZE/sizeof(char *)];
};

char *tpl_timestamp_to_string(struct timeval *tstamp);
#endif /* _TUPLE_H_ */
