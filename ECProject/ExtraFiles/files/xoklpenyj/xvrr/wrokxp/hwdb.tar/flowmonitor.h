/*
 * interface and data structures associated with flow monitor
 */
#ifndef _FLOWMONITOR_H_INCLUDED_
#define _FLOWMONITOR_H_INCLUDED_

#include <netinet/ip.h>			/* defines in_addr */

typedef struct flow_data {
    unsigned char proto;
    struct in_addr ip_src;
    struct in_addr ip_dst;
    unsigned short sport;
    unsigned short dport;
    unsigned long packets;
    unsigned long bytes;
} FlowData;

typedef struct bin_results {
    unsigned long nflows;
    FlowData **data;
} BinResults;

/*
 * convert Rtab results into BinResults
 */
BinResults *mon_convert(Rtab *results);

/*
 * free heap storage associated with BinResults
 */
void mon_free(BinResults *p);

#endif /* _FLOWMONITOR_H_INCLUDED_ */
