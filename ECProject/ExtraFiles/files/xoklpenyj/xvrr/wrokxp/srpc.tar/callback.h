/*
 * callback.h - defines used by callbackclient and callbackserver
 */

#ifndef _CALLBACK_H_DEFINED_
#define _CALLBACK_H_DEFINED_

#define CB_PORT 20001
#define CB_NAME "Callback"

#endif /* _CALLBACK_H_DEFINED_ */
